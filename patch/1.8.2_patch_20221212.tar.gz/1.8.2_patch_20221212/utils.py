import logging
import re
import time
from functools import wraps
from sqlalchemy import and_
import zipfile
from datetime import datetime

import jinja2
import psutil
import telnetlib
import yaml
from flask import json, request, Response, current_app
import flask_login
import tarfile, os
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from server.ansible_lib.pica_lic import pica8_license
import geocoder
from server.constants import PICOS_V_SN
from server.db.models.inventory import Switch, SwitchConfigBackup, License, SwitchSystemInfo,\
    AssociationGroup, VpnConfig, SwitchParking
from server.db.models.monitor import Event, LicenseCount, LicenseStatisttic
from server.db.models.user import User
from server.db.models.inventory import inven_db, SwitchAutoConfig
from server.db.models.user import user_db
from server.db.models.monitor import monitor_db
from server.db.models import general
from server.db.models import inventory
from server import cfg, constants
from server.util import str_helper
import shutil

from tacacs_plus.client import TACACSClient
import socket
import json
from server.util.pica8_query import Pica8Query

LOG = logging.getLogger(__name__)


class StringLoader(jinja2.BaseLoader):
    def get_source(self, environment, template):

        db_temp = general.general_db.get_model(general.GeneralTemplate, filters={"name": [template]})

        if not db_temp or db_temp == '':
            raise jinja2.TemplateNotFound(template)

        def uptodate():
            try:
                return False
            except OSError:
                return False

        return db_temp.j2_template, None, uptodate


env = jinja2.Environment(loader=jinja2.FileSystemLoader(searchpath="."),
                         trim_blocks=True,
                         lstrip_blocks=True)


def str2bool(strs):
    return True if strs.lower() == 'true' else False


def check_auth(username, password):
    user = user_db.query_user(user=username)
    if not user or user.passwd != password:
        return False
    return True

def tacacs_auth(username, password): # return (tacacs_enable, (authentication_status, authorization_role))
    username = username.encode('ascii')
    password = password.encode('ascii')
    tacacs_setting = user_db.get_tacacs_config()
    if tacacs_setting.enable:
        for host in [tacacs_setting.server_host.encode('ascii'), tacacs_setting.server_host_ii.encode('ascii')]:
            if not host:
                continue
            cli = TACACSClient(host.encode('ascii'), 49, tacacs_setting.server_secret.encode('ascii'), timeout=tacacs_setting.session_timeout, family=socket.AF_INET)
            try:
                auth = cli.authenticate(username, password)
                if auth.valid:
                    # authentication success
                    author = cli.authorize(username, arguments=[b"service=AmpCon", b"cmd="])
                    if author.valid:
                        # authorize success
                        try:
                            for arg in author.arguments:
                                if 'priv-lvl=' in arg:
                                    user_priv = int(arg.replace('priv-lvl=', '').replace('privilege-level=',''), 10)
                                    user_mapping = json.loads(tacacs_setting.user_mapping) if tacacs_setting.user_mapping else {}
                                    for role in user_mapping.keys():
                                        user_level_range =  range(user_mapping[role][0], user_mapping[role][0]+1)
                                        if user_priv in user_level_range:
                                            return True, (True, role)
                        except Exception, _:
                            return True, (True, 'readonly')
                        return True, (True, 'readonly')
                    else:
                        #authorize failed
                        return True, (True, 'readonly')
                else:
                    # authentication failed
                    return True, (False, '')
            except Exception, _:
                continue
        # Add LOG for fallback
        LOG.warn('TACACS+ fallback: user "{0}" trying to login with local credential '.format(username))
        monitor_db.add_operation_log(username, '/login', 'tacacs_auth', 'success', 'username: {0} password:XXXXX'.format(username), 
            'TACACS+ fallback: user "{0}" trying to login with local credential '.format(username))
    return False, (False, '')

def user_req(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        username = flask_login.current_user.id
        if flask_login.current_user.role == 'tacacs':
            return f(flask_login.current_user, *args, **kwargs)
        user = user_db.query_user(username)
        return f(user, *args, **kwargs)

    return decorated_function


def operation_log(method=None, contents='', require_methods=None):
    def _wrap(f):
        @wraps(f)
        def wrap(*args, **kwargs):

            result = f(*args, **kwargs)
            try:
                # add operation log
                user = flask_login.current_user.id
                if user and (not require_methods or request.method in require_methods):
                    path = request.path
                    params = request.form.copy().to_dict(
                        flat=True) or request.get_json() or request.args.copy().to_dict(flat=True) or {}
                    params.update(kwargs)
                    params_str = json.dumps(params)
                    params_str = params_str.replace('"', '').replace('{', '').replace('}', '').replace(',', '')
                    params_str = params_str.replace(': ', ':')
                    log_method = method or f.__name__
                    content = contents.format(*args, **params)
                    if isinstance(result, str):
                        status = 'success' if 'error' not in result else 'error'
                    elif isinstance(result, Response):
                        if result.status_code == 200:
                            data = result.data
                            try:
                                data = json.loads(data)
                                if 'status' in data:
                                    status = 'success' if str(data['status']) == '200' else 'error'
                                elif 'error' in data and data['error']:
                                    status = 'error'
                                elif ('fail' in data and data['fail']) or ('failed' in data and data['failed']):
                                    status = 'error'
                                else:
                                    status = 'success'
                            except Exception, _:
                                status = 'success'
                        else:
                            status = 'error'
                    else:
                        status = 'success'
                    if status == 'success':
                        LOG.info('%s %s status:[%s]', user, content, status)
                    else:
                        LOG.error('%s %s status:[%s]', user, content, status)
                    monitor_db.add_operation_log(user, path, log_method, status, params=params_str, content=content)
            except Exception as ex:
                LOG.exception('error in add operation log [%s]', ex)

            return result

        return wrap

    return _wrap


def base_info(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        event = monitor_db.get_collection(Event, filters={'status': ['unread']}, sorts=[('create_time', False)])
        # event = db_session.query(Event).filter(Event.status == 'unread').all()[0:5]
        return f(event, *args, **kwargs)

    return decorated_function


def find_template_path(hardware_model, flag, version=None):
    # path = os.path.join('config_gen', hardware_model)
    # file_name = 'switch_' + flag + '_config' if flag != '' else 'switch_config'
    # if version:
    #     version_prefixs = re.findall('.*([2-3].[0-9]+).', version)
    #     if len(version_prefixs) > 0:
    #         file_name += '_' + version_prefixs[0].replace('.', '_')
    # file_name += '.j2'
    # return os.path.join(path, file_name)
    if flag != '':
        path = 'config_gen/' + hardware_model + '/switch_' + flag + '_config'
    else:
        path = 'config_gen/' + hardware_model + '/switch_config'
    if version:
        version_prefixs = re.findall('.*([2-3]\.[0-9]+).', version)
        if len(version_prefixs) > 0:
            return path + '_' + version_prefixs[0].replace('.', '_') + '.j2'
    return path + '.j2'


def generate_config(tem_path, data):
    template = env.get_template(tem_path)
    return template.render(data)


def get_CPU_state(time_count=1):
    return {'cpu_count': str(psutil.cpu_count(logical=False)),
            'cpu_percent': str(psutil.cpu_percent(time_count, 0)) + "%"}


def get_memory_state():
    phymem = psutil.virtual_memory()
    memory = dict()
    memory['total'] = str(int(phymem.total / 1024 / 1024)) + "M"
    memory['used'] = str(int(phymem.used / 1024 / 1024)) + "M"
    memory['free'] = str(int(phymem.free / 1024 / 1024)) + "M"
    memory['sum_mem'] = str(float(phymem.used / 1024 / 1024) / float(phymem.total / 1024 / 1024) * 100)[0:5] + "%"
    return memory


# function of disk state
def get_disk_satate():
    diskinfo = psutil.disk_usage('/')
    disk = {
        'total': str(int(diskinfo.total / 1024 / 1024 / 1024)) + "G",
        'used': str(int(diskinfo.used / 1024 / 1024 / 1024)) + "G",
        'free': str(int(diskinfo.free / 1024 / 1024 / 1024)) + "G",
        'sum_disk': str(float(diskinfo.used / 1024 / 1024 / 1024) / float(diskinfo.total / 1024 / 1024 / 1024) * 100)[
                    0:5] + "%"
    }
    return disk


# function of proscess state
def check_process_state(process_name):
    for i in psutil.process_iter():
        if i.name() == process_name:
            str_tmp = str(i.name()) + "-" + str(i.pid) + "-" + str(i.status())
            return (str_tmp)


def time_now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def send_email_with_event(sn, e_type):
    sub = "deploy %s %s" % (sn, e_type)
    switch_logs = inven_db.get_switch_log(sn)
    contents = [switch_log.content for switch_log in switch_logs]
    msg = '\n'.join(contents)
    users = user_db.get_collection(User, {'sn': [sn]})
    receivers = []
    for user in users:
        if user.type in ['admin', 'superuser'] and user.email:
            receivers.append(user.email)
    send_email(sub, msg, receivers)


def send_email(sub, msg, receivers):
    """
     send email msg to receivers
    :param sub: title for email
    :param msg: body for email
    :param receivers: send to users
    :return:
    """
    assert cfg.CONF.mail.server and cfg.CONF.mail.port and cfg.CONF.mail.user and cfg.CONF.mail.password, \
        "mail server,port,user,password must be set"
    message = MIMEText(msg, 'plain', 'utf-8')
    message['From'] = Header(cfg.CONF.mail.user, 'utf-8')
    message['To'] = Header(",".join(receivers), 'utf-8')
    message['Subject'] = Header(sub, 'utf-8')
    try:
        mail_server = smtplib.SMTP(cfg.CONF.mail.server, cfg.CONF.mail.port)
        mail_server.ehlo()
        mail_server.starttls()
        mail_server.login(cfg.CONF.mail.user, cfg.CONF.mail.password)
        mail_server.sendmail(cfg.CONF.mail.user, receivers, message.as_string())
        mail_server.quit()
    except Exception:
        return False
    return True


def generate_config_from_yaml(template_path, yaml_path):
    yaml_data = yaml.load(open(yaml_path))
    template = env.get_template(template_path)
    return template.render(yaml_data)


def str_json(yaml_str):
    yaml_str_new = yaml_str.replace("u'", '"').replace("'", '"')
    return json.loads(yaml_str_new)


def update_db_license_count():
    try:
        system_config = inven_db.get_mgt_system_config()
        if system_config:
            LOG.debug("get license count by user %s", system_config.license_portal_user)
            if not pica8_license.inited:
                pica8_license.fresh(user_name=system_config.license_portal_user,
                                    password=system_config.license_portal_password,
                                    url=system_config.license_portal_url)

            inventory = pica8_license.get_inventory_all()
            if not inventory:
                LOG.error("error get license count from %s", system_config.license_portal_url)
            elif 'error' in inventory:
                LOG.error('error in get inventory from %s, message %s', system_config.license_portal_url,
                          inventory['error'])
            elif 'CompanyName' in inventory:
                update_num = monitor_db.update_model(LicenseStatisttic, {}, {'total': inventory['TotalCount'], 'remain': [inventory['AvaliableCount']]})
                if update_num < 1:
                    monitor_db.insert(LicenseStatisttic(total= inventory['TotalCount'], remain=inventory['AvaliableCount']))
            elif 'response' in inventory:
                for license_count in inventory['response']:
                    update_num = monitor_db.update_model(LicenseCount, {'speed_type': [license_count['speed']],
                                                                        'feature_type': [license_count['type']]},
                                                         {'total': license_count['total'],
                                                         'remain': [license_count['remaining']]})
                    if update_num < 1:
                        monitor_db.insert(LicenseCount(speed_type=license_count['speed'],
                                                       feature_type=license_count['type'],
                                                       total=license_count['total'],
                                                       remain=license_count['remaining']))
        else:
            LOG.error("license portal token haven't set")
    except Exception as e:
        LOG.exception("error in update db license count %s", e)


def update_switch_status(interval):
    while True:
        # get status
        pass


def update_switch_status1(f):
    @wraps(f)
    def _update_warp(*args, **kwargs):
        res, status = f(*args, **kwargs)
        LOG.info('update switch %s status %s', args[0], status)
        inven_db.update_switch_status(args[0], status)
        return res, status
    return _update_warp


def un_tar(tar_path, model):
    tar = tarfile.open(tar_path)
    untar_file_final = os.path.join('patch_gen', model)
    if os.path.exists(untar_file_final):
        shutil.rmtree(untar_file_final)
    if not os.path.exists(untar_file_final):
        os.makedirs(untar_file_final)
    names = tar.getnames()
    for name in names:
        tar.extract(name, untar_file_final)
    return untar_file_final


def get_latlong(address):
    # url = 'None'
    # api_name = 'osm'
    # if url == None:
    #     g_result = getattr(geocoder, api_name)(address, proxies=cfg.CONF.license_portal_proxy)
    # else:
    #     g_result = getattr(geocoder, api_name)(address, proxies=cfg.CONF.license_portal_proxy)
    return Pica8Query(address, proxies=cfg.CONF.license_portal_proxy)


def get_db_sync_ip():
    result_proxy = None
    try:
        result_proxy = inven_db.get_session().execute('show slave status')
        replication_status = result_proxy.first()
        if not replication_status:
            return None, None, False
        return replication_status['Master_Host'], replication_status['Master_Server_Id'], \
               replication_status['Slave_IO_Running'] == 'Yes' and replication_status['Slave_SQL_Running'] == 'Yes'
    except Exception as e:
        LOG.exception('error in get db sync ip %s', e)
        return None, None, False
    finally:
        if result_proxy:
            result_proxy.close()


def get_switch_default_user():
    global_config = inven_db.get_mgt_system_config()
    return global_config.switch_op_user, global_config.switch_op_password


def multi_table_page_helper(args, models, joins, rule=None, extra_filter=None, json_data=True):
    """
    e.g.::
        multi_table_page_helper(request.args, (Switch, SwitchLog,), ((SwitchLog, Switch.sn == SwitchLog.sn,),),
                                rule=(Switch.sn=='test',), extra_filter=(Switch.status=='Staged'), josn_data=False)

    :param args: requests.args
    :param models: database model to query
    :param joins: join conditions
    :param rule: filter rules
    :param extra_filter: not Datatable filter
    :param json_data: if true return dict else return json str
    :return:
    """
    start = int(args.get('start'))
    length = int(args.get('length'))
    order_column_index = args.get('order[0][column]')
    order_column = args.get('columns[' + order_column_index + '][data]')
    order_dir = args.get('order[0][dir]')

    order = None
    if order_column:
        for model in models:
            column = getattr(model, order_column, None)
            if column:
                if order_dir == 'desc':
                    order = (column.desc(),)
                else:
                    order = (column.asc(),)
                break

    session = inven_db.get_session()
    with session.begin():
        query = session.query(*models)
        for join in joins:
            query = query.outerjoin(*join)

        if order is not None:
            query = query.order_by(*order)

        if extra_filter is not None:
            query = query.filter(extra_filter)

        records_total = query.count()

        if rule is not None:
            query = query.filter(rule)

        records_filtered = query.count()
        results = query.slice(start, start + length).all()

        data = []
        for result in results:
            first_slice = result[0].make_dict()
            for obj in result[1:]:
                if not obj:
                    continue
                prefix = obj.__class__.__name__.lower() + '_'
                first_slice.update(dict(((prefix + col.name, getattr(obj, col.name)) for col in obj.__table__.columns
                                   if getattr(obj, col.name))))
            data.append(first_slice)

        if json_data:
            return json.dumps({'data': data, 'recordsTotal': records_total, 'recordsFiltered': records_filtered},
                              default=str)
        else:
            return {'data': data, 'recordsTotal': records_total, 'recordsFiltered': records_filtered}


def page_helper(args, model, rule=None, extra_filter=None, json_data=True, session=None, order_by=None):
    start = int(args.get('start'))
    length = int(args.get('length'))
    draw = int(args.get('draw'))

    order_column_index = args.get('order[0][column]')
    order_column = args.get('columns[' + order_column_index + '][data]')
    order_dir = args.get('order[0][dir]')

    if order_column:
        if order_dir == 'desc':
            order = getattr(model, order_column).desc()
        else:
            order = getattr(model, order_column).asc()
    else:
        order = None

    session = session or inven_db.get_session()
    with session.begin():
        query = session.query(model)
        if order_by is not None:
            query = query.order_by(order_by)
        if order is not None:
            query = query.order_by(order)

        if extra_filter is not None and type(extra_filter) == list:
            query = query.filter(*extra_filter)
        elif extra_filter is not None:
            query = query.filter(extra_filter)

        records_total = query.count()

        if rule is not None:
            query = query.filter(rule)

        records_filtered = query.count()
        results = query.slice(start, start + length).all()
        if json_data:
            data = [result.make_dict() for result in results]

            return json.dumps({'data': data, 'recordsTotal': records_total, 'recordsFiltered': records_filtered},
                              default=str)
        else:
            return {'data': results, 'recordsTotal': records_total, 'recordsFiltered': records_filtered}


def page_helper_lifecycle(args, rule=None, status_filter=None, group_name=None, session=None):
    start = int(args.get('start'))
    length = int(args.get('length'))
    draw = int(args.get('draw'))

    order_column_index = args.get('order[0][column]')
    order_column = args.get('columns[' + order_column_index + '][data]')
    order_dir = args.get('order[0][dir]')

    if order_column:
        column = getattr(Switch, order_column, None)
        if not column:
            if order_column == 'license_status':
                order_column = 'status'
            column = getattr(License, order_column, None)

        if order_column == 'flag':
            column = SwitchConfigBackup.back_up_type

        if order_column == 'backup_time':
            column = SwitchConfigBackup.modified_time

        if not column:
            column = getattr(SwitchSystemInfo, order_column, None)

        if order_dir == 'desc':
            if order_column == 'version':
                order = (column.desc(), Switch.revision.desc())
            else:
                order = (column.desc(), )
        else:
            if order_column == 'version':
                order = (column.asc(), Switch.revision.asc())
            else:
                order = (column.asc(), )
    else:
        order = None

    session = session or inven_db.get_session()
    with session.begin():
        query = session.query(Switch, License, SwitchSystemInfo, SwitchConfigBackup)\
            .outerjoin(License, Switch.sn == License.sn_num) \
            .outerjoin(SwitchSystemInfo, Switch.platform_model == SwitchSystemInfo.model)\
            .outerjoin(SwitchConfigBackup,
                       and_(Switch.sn == SwitchConfigBackup.sn, Switch.mgt_ip == SwitchConfigBackup.ip))

        if group_name:
            query = query.outerjoin(AssociationGroup, Switch.sn == AssociationGroup.switch_sn).filter(
                AssociationGroup.group_name == group_name
            )

        if order is not None:
             query = query.order_by(*order)

        if status_filter is not None and type(status_filter) == list:
            query = query.filter(*status_filter)
        elif status_filter is not None:
            query = query.filter(status_filter)

        records_total = query.count()

        if rule is not None:
            query = query.filter(rule)

        records_filtered = query.count()

        results = query.slice(start, start + length).all()
        data = []
        for result in results:
            switch_dict = result.Switch.make_dict()
            if 'version' not in switch_dict:
                data.append(switch_dict)
                continue
            if result.License:
                license_dict = result.License.make_dict()
                license_dict.pop('create_time')
                license_dict.pop('modified_time')
                license_dict.pop('sn_num')
                license_dict.pop('id')
                switch_dict['license_status'] = license_dict.pop('status')
                switch_dict.update(license_dict)
            if result.SwitchSystemInfo:
                switch_dict['up_to_date_version'] = result.SwitchSystemInfo.up_to_date_version
            if result.SwitchConfigBackup:
                if result.SwitchConfigBackup.back_up_type == 0:
                    switch_dict['flag'] = 'Unknown'
                elif result.SwitchConfigBackup.back_up_type == 1:
                    switch_dict['flag'] = 'R'
                else:
                    switch_dict['flag'] = 'U'
                switch_dict['backup_time'] = result.SwitchConfigBackup.modified_time
            switch_dict['version'] = switch_dict.pop('version') + '/' + switch_dict.pop('revision')
            data.append(switch_dict)

        return json.dumps({'data': data, 'recordsTotal': records_total, 'recordsFiltered': records_filtered},
                          default=str)


def pathch_path(path):
    if ',' in path:
        path = path.split(',')
        path_split = path[0].split('/')
    elif ';' in path:
        path = path.split(';')
        path_split = path[0].split('/')
    else:
        path_split = [path]
    if path_split[0]:
        path_res = path_split[0]
    else:
        path_res = path_split[1]
    return path_res


def conform_task_type():
    from server.util import http_client
    ip, server_id, running = get_db_sync_ip()
    LOG.info('get db sync ip:%s, server_id:%s, running:%s', ip, server_id, running)
    if not ip or not running:
        return 'all'

    random_user = user_db.get_model(User)
    if not http_client.conform_sync_server_ok(random_user.name, ip):
        return 'all'

    if server_id == 1:
        return 'import'

    return 'deploy'


def switch_config_backup(ip, date_dict):
    switch_config_backup = inven_db.get_model(SwitchConfigBackup, filters={'ip': [ip]})
    if switch_config_backup:
        if switch_config_backup.back_up_type == constants.SWITCH_BACK_MANUAL:
            date_dict['flag'] = 'U'
        elif switch_config_backup.back_up_type == constants.SWITCH_BACK_AUTO:
            date_dict['flag'] = 'R'
        date_dict['backup_time'] = switch_config_backup.modified_time
    else:
        date_dict['flag'] = 'unknown'
        date_dict['backup_time'] = '---'
    return date_dict


def get_system_user():
    # should be changed here in later
    user = user_db.get_model(User, filters={'type': ['admin', 'superuser', 'superadmin']})
    return user.name, user.passwd


def get_parking_security_config():
    return inventory.inven_db.get_mgt_system_config().parking_security_config


def is_need_to_push_security_config_again(sn):
    switch_parked = inven_db.get_model(SwitchParking, filters={'sn': [sn]})
    return True if not switch_parked or (datetime.now() - inven_db.get_model(SwitchParking, filters={'sn': [sn]}).last_register).total_seconds() > 60 else False


def switch_need_save_config(platform):
    platforms = {'N3048EP-ON', 'N3048ET-ON', 'N3024EP-ON', 'N3024ET-ON', 'N3132PX-ON'}
    if platform in platforms:
        return True
    return False


def get_vpn_status_file_content():
    status_content = ''
    if not os.path.exists(constants.OPENVPN_CONFIG_FILE):
        LOG.error("Openvpn configuration file: {0} is not existed".format(constants.OPENVPN_CONFIG_FILE))
        return ''
    config_content = ''
    with open(constants.OPENVPN_CONFIG_FILE) as fc:
        config_content = fc.read()
        if re.search('\nstatus (.*)\n', config_content):
            status_log_path =  re.search('\nstatus (.*)\n', config_content).group(1)
        else:
            LOG.error('Can not find Openvpn status file path.')
            return ''

        if not os.path.exists(status_log_path):
            LOG.error("Openvpn status file: {0} is not existed".format(status_log_path))
            return ''
        with open(status_log_path) as fs:
            status_content = fs.read()
            return status_content
    return status_content

def update_vpn_client_status():
    str_client = get_vpn_status_file_content()
    client_list = re.findall('10.[0-9]+\.[0-9]+\.[0-9]+,([0-9a-zA-Z-_\.# ]+),[0-9]+\.+[0-9]+',str_client)
    vip_client_list = re.findall('(10.[0-9]+\.[0-9]+\.[0-9]+),([0-9a-zA-Z-_\.# ]+),[0-9]+\.+[0-9]+',str_client)
    for switch in inven_db.get_collection(Switch, filters={}):
        if switch.reachable_status in [1,2] and (switch.sn in client_list or switch.remark in client_list):
            switch.reachable_status = 0
        elif switch.reachable_status in [0,3] and switch.sn not in client_list and switch.remark not in client_list:
            switch.reachable_status = 1
    if len(client_list)>0:
        LOG.info('Active VPN %d clients', len(client_list))
        inven_db.update_model(VpnConfig, filters={}, updates={VpnConfig.vpn_online_status: False})
        for client in client_list:
            inven_db.update_model(VpnConfig, filters={'sn': [client]}, updates={VpnConfig.vpn_online_status: True})
        #we need also update the VPN ip address in database
        for vip_client in vip_client_list:
            inven_db.update_model(Switch, filters={'sn': [vip_client[1]]}, updates={Switch.mgt_ip: vip_client[0]})
            inven_db.update_model(Switch, filters={'remark': [vip_client[1]]}, updates={Switch.mgt_ip: vip_client[0]})

def update_vpn_link_ip_addr():
    str_client = get_vpn_status_file_content()
    # vip_client_list format: [('10.8.0.30', 'EC1741001625', '10.10.51.217'), ('10.8.0.10', 'EC1750001004', '10.10.51.224')]
    vip_client_list = re.findall('(10.[0-9]+\.[0-9]+\.[0-9]+),([0-9a-zA-Z-_\.# ]+),([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)',str_client)

    for vip_client in vip_client_list:
        inven_db.update_model(Switch, filters={'sn': [vip_client[1]]}, updates={Switch.link_ip_addr: vip_client[2]})
        inven_db.update_model(Switch, filters={'remark': [vip_client[1]]}, updates={Switch.link_ip_addr: vip_client[2]})

def wrap_file_stream(data, filename, as_attachment=True):
    import mimetypes
    from werkzeug.datastructures import Headers
    mimetype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'

    headers = Headers()
    if as_attachment:
        headers.add('Content-Disposition', 'attachment',
                    filename=filename)

    headers['Content-Length'] = len(data)

    rv = current_app.response_class(data, mimetype=mimetype, headers=headers,
                                    direct_passthrough=True)
    return rv

def zipFolder(zip_path, zip_file_path):
    zip_file = zipfile.ZipFile(zip_file_path, "w", zipfile.ZIP_DEFLATED)
    for path, _, filenames in os.walk(zip_path):
        fpath = path.replace(zip_path, '')
        for filename in filenames:
            zip_file.write(os.path.join(path,filename),os.path.join(fpath,filename))
    zip_file.close()

def unzipFile(zip_file_path, unzip_path):
    os.makedirs(unzip_path)
    zip_file = zipfile.ZipFile(zip_file_path)
    zip_list = zip_file.namelist()

    for f in zip_list:
        zip_file.extract(f, unzip_path)
    
    zip_file.close()


def get_picos_v():
    return inven_db.get_session().query(Switch).filter(Switch.sn == "PICOS-V")


def modify_picos_v_switch_list(model):
    try:
        inven_db.get_session().query(Switch).filter(Switch.sn == "PICOS-V").update({"platform_model": model})
        inven_db.get_session().commit()
    except:
        return


def get_picos_v_support_model_list():
    support_mode = {'AS4630-54NPE', 'AS4630-54PE', 'N2224PX-ON', 'N2224X-ON', 'N2248PX-ON', 'N2248X-ON', 'N3208PX-ON',
                    'N3224F-ON', 'N3224P-ON', 'N3224PX-ON', 'N3224T-ON', 'N3248P-ON', 'N3248PXE-ON', 'N3248TE-ON',
                    'N3248X-ON', 'S4048-ON', 'S4128F-ON', 'S4128T-ON', 'S4148F-ON', 'S4148T-ON', 'S5212F-ON',
                    'S5224F-ON', 'S5232F-ON', 'S5248F-ON', 'S5296F-ON', 'Z9100-ON', 'Z9264F-ON', 'ag5648', 'ag7648',
                    'ag9032', 'as5712_54x', 'as5812_54t', 'as5812_54x', 'as5835_54t', 'as5835_54x', 'as7312_54x',
                    'as7326_56x', 'as7712_32x', 'as7726_32x', 'as7816_64x'}
    automation_support_model = set(cfg.CONF.supports_models)
    return sorted(list(support_mode & automation_support_model), key=str.upper)


def is_valid_switch_model_name(model_name):
    return True if model_name in cfg.CONF.supports_models else False


def remove_picos_v_in_switch_list(switch_list):
    for switch in switch_list:
        if switch.sn == PICOS_V_SN:
            switch_list.remove(switch)
            break
    return switch_list


def get_search_models(custom_models=None):
    session = inven_db.get_session()
    if custom_models:
        platform_models = session.query(inventory.Switch.platform_model).group_by(
            inventory.Switch.platform_model).all()
        models = [p_models.platform_model for p_models in platform_models]
    else:
        models = cfg.CONF.supports_models
    tmp_dict = dict()
    for model in models:
        model_mapping_obj = session.query(inventory.SwitchSystemInfo).filter(
            inventory.SwitchSystemInfo.model == model).first()
        if model_mapping_obj and model_mapping_obj.platform:
            if model_mapping_obj.platform not in tmp_dict:
                tmp_dict[model_mapping_obj.platform.encode("utf-8")] = [model]
            else:
                tmp_dict[model_mapping_obj.platform.encode("utf-8")].append(model)
    return tmp_dict


if __name__ == "__main__":
    pass

