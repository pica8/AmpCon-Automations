import datetime
import json
import logging
import os
import platform
import re

from flask import (
    Blueprint,
    request,
    render_template,
    redirect,
    jsonify,
    current_app,
    Response
)
from flask_login import login_user, logout_user
from sqlalchemy import func
from sqlalchemy import or_, and_

from server import constants
from server.db.models import inventory, monitor, general
from server.db.models.inventory import inven_db, Switch, AssociationGroup, SwitchAutoConfig
from server.db.models.monitor import monitor_db
from server.db.models.sdn_access import SdnAccessSwitch, sdn_access_db
from server.db.models.user import user_db
from server.db.models.vtep import VtepControlSwitch, vtep_db
from server.task_manage import forking_manage
from server.user import User
from server.util import pure_utils
from server.util import utils, str_helper
from server.util.ssh_util import switch_picos_v_model
from server.util.utils import modify_picos_v_switch_list, get_picos_v_support_model_list, get_parking_security_config

from server.auth_jwt import Auth_Handles, web_auth

if platform.system() == 'Windows':
    from server.deploy_switch import RegSwitch as DeployDriver
else:
    from server.ansible_deploy_switch import AnsibleDeploySwitch as DeployDriver
from server import log as server_log
from server import cfg

dashboard_mold = Blueprint("mold", __name__, template_folder='templates')
LOG = logging.getLogger(__name__)
MAX_AUTH_ERROR = 1
key_reg = re.compile('key\s+([^\s]+)')
password_reg = re.compile('password\s+([^\s]+)')
auth_handles = Auth_Handles()

@dashboard_mold.route('/reg/<string:info>', methods=['GET'])
def reg_switch(info):
    info_list = info.split(';')
    if not info_list[0]:
        return 'bad params'

    info = dict(
        sn=info_list[0].encode('utf8'),
        ip=info_list[1].encode('utf8'),
        model=info_list[2].encode('utf8'),
        hwid=info_list[3].encode('utf8'),
        flag=int(info_list[4].encode('utf8')) if len(info_list) >= 5 else 0,
        # 0: inband 1: manage 2:vpn
        uplink_type=int(info_list[5].encode('utf8')) if len(info_list) >= 6 else 0,
        # for support dell switch service code or tag
        service_code=info_list[6].encode('utf8') if len(info_list) >= 7 else ''
    )

    if info['flag'] == 0:
        inven_db.delete_collection(inventory.DeployedSecuritySwitch, filters={'sn': [info['sn']]})

    # handle service code
    if info['service_code'] != '':
        switch = inven_db.get_switch_info_by_sn(info['service_code'])
        if switch:
            check_switch = inven_db.get_switch_info_by_sn(info['sn'])
            if check_switch:
                inven_db.add_switch_log(info['service_code'], 'The switch sn %s have already exist' % info['sn'],
                                        level='warn')
                return Response('The switch sn %s have already exist' % info['sn'], status=500)

            # update switch sn and service code
            inven_db.update_model(Switch, {'sn': [info['service_code']]},
                                  {'sn': info['sn'], 'remark': info['service_code']})
            inven_db.update_model(SwitchAutoConfig, {'name': [info['service_code'] + '_site_config']},
                                  {'name': info['sn'] + '_site_config'})

    switch = inven_db.get_switch_info_by_sn(info['sn'])

    if info['flag'] == 3:
        switch = switch or inven_db.get_model(inventory.Switch, filters={'sn': [info['sn']]})

        if switch.upgrade_status == constants.outswitch_status.UPGRADING:
            return 'upgrading'
        elif switch.upgrade_status == constants.outswitch_status.UPGRADE_FAILED:
            return 'upgrade failed'
        elif switch.upgrade_status == constants.outswitch_status.UPGRADED:
            return 'upgraded'
        return 'not-upgraded'

    # if switch and switch.status == 'Provisioning Success':
    #     return "already deployed"

    reg = DeployDriver(info)
    deployed_security_switch = inven_db.get_model(inventory.DeployedSecuritySwitch, filters={'sn': [info['sn']]})
    if not switch:
        LOG.info("switch %s haven't been configured", info['sn'])
        monitor_db.add_event(info['sn'], 'warn',
                           'switch %s registered, but have not been configured' % info['sn'])

        # push parking security file and execute it
        if not deployed_security_switch and get_parking_security_config():
            forking_manage.add_task(info['sn'], reg.start_push_parking_security_config)

        inven_db.update_switch_lot(info['sn'], info['ip'], info['model'])
        return "switch haven't been configured"

    if not switch.enable and switch.import_type == constants.ImportType.RMA:
        LOG.info("rma switch %s haven't staged ", info['sn'])
        monitor_db.add_event(info['sn'], 'warn',
                           'switch %s registered, but have not been staged' % info['sn'])

        # push parking security file and execute it
        if not deployed_security_switch and get_parking_security_config():
            forking_manage.add_task(info['sn'], reg.start_push_parking_security_config)

        return "switch haven't been staged"

    if not switch.enable:
        LOG.info("switch %s haven't staged", info['sn'])
        if switch.status != 'Registered Not-staged':
            monitor_db.add_event(info['sn'],
                               'warn', 'switch [sn:%s,ip:%s,model:%s,hwid:%s] registered, but have not staged' %
                               (info['sn'], info['ip'], info['model'], info['hwid']))
            inven_db.update_status(info['sn'], 'Registered Not-staged')

        if not deployed_security_switch:
            reg.check_register()
            forking_manage.add_task(info['sn'], reg.start_push_security_config)

        return "switch haven't been staged"
    else:
        inven_db.delete_collection(inventory.SwitchParking, filters={'sn': [info['sn']]}, session=inven_db.get_session())
        LOG.info("switch %s have been removed from SwitchParking", info['sn'])

    if deployed_security_switch and deployed_security_switch.invalid_times >= MAX_AUTH_ERROR:
        return Response('invalid tacacs user, please reinit', status=400)

    inven_db.update_model(inventory.Switch, {'sn': [info['sn']]}, {'tmp_ip': info['ip']})

    task_running = forking_manage.is_task_run(info['sn'])

    if task_running and info['flag'] != 0:
        LOG.info('switch %s is in deploying', info['sn'])
        return "switch deploy is running"

    step = switch.step
    if info['flag'] == 0:
        LOG.info('switch %s re inited, update status to 0', info['sn'])
        inven_db.update_step(info['sn'], 0)
        step = 0
        if task_running:
            # switch re inited kill child process, restart deploy
            try:
                forking_manage.kill_process(info['sn'])
            except Exception as e:
                LOG.exception(e)

    inven_db.update_status(info['sn'], 'Registered')

    if step < 6:
        reg.check_register()

        def error_hanlder(e):
            inven_db.add_switch_log(info['sn'], e.message, level='error')
            monitor_db.add_event(info['sn'], 'error', 'run task failed %s' % e.message)
            inven_db.update_status(info['sn'], 'Provisioning Failed')
            utils.send_email_with_event(info['sn'], 'error')

        if switch.import_type == constants.ImportType.RMA or inven_db.get_switch_back_sn(info['sn']):
            forking_manage.add_task(info['sn'], reg.start_rma, error_callback=error_hanlder)
        else:
            forking_manage.add_task(info['sn'], reg.start, error_callback=error_hanlder)

    # db.add_switch_log(info['sn'], 'Task: Switch Registered    ::: Result: Success', level='info')
    return jsonify('registered')

@dashboard_mold.route('/reg/vpn/time', methods=['GET'])
def system_time():
    return datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

@dashboard_mold.route('/deploy/failed', methods=['POST'])
def handle_deploy_fail():
    """
    this function should handle deploy failed message
    json eg:
    {'sn': 'test11',
     'task_name': 'push full config task',
     'reason': 'cmd not found'
    }
    :return:
    """
    params = request.get_json()
    sn = params['sn']
    task_name = params['task_name']
    reason = params['reason']
    inven_db.add_switch_log(sn, 'task %s failed, reason[%s]' % (task_name, reason), level='error')
    return 'handled'


def push_sflow_config_handle(sn, result):
    # In later, we need asdd some logic in here
    pass


@dashboard_mold.route('/vpn_update_ip/<string:info>', methods=['GET'])
def vpn_update_ip(info):
    info_list = info.split(';')
    if not info_list[0]:
        return 'bad params'

    info = dict(
        sn=info_list[0].encode('utf8'),
        ip=info_list[1].encode('utf8')
    )
    switches = inven_db.get_switch_info_by_sn(info['sn'])
    # switches = db.get_collection(Switch, filters={'sn': [info['sn']]})
    if not switches:
        LOG.info("Unknown switch %s try to update VPN IP", info['sn'])
        monitor_db.add_event(info['sn'], 'warn',
                             'Unknown switch %s try to update VPN IP' % info['sn'])
    elif switches.status == "Provisioning Success":
        inven_db.update_model(inventory.Switch, {'sn': [info['sn']]}, {'mgt_ip': info['ip']})
        # we still need update sflow source-ip, otherwise, will lost sflow
        # global_config = inven_db.get_mgt_system_config()
        # user = global_config.switch_op_user
        # pw = global_config.switch_op_password
        # finial_pending_config = "configure;set protocols sflow agent-id " + info['ip']+ \
        #                         ";set protocols sflow source-address " + info['ip']+ ";commit"
        # host_map = dict()
        # map(lambda switch: host_map.update({switch.mgt_ip: switch.sn}), [switches])
        # cmd = '/pica/bin/pica_sh -c '+ '"'+ finial_pending_config + '"'
        # tasks = [ansible_common.command_task('Push user L2L3 config',
        #                                      cmd, tags=[])
        #         ]
        # callback = ansible_common.SwitchOperCallback(host_map)
        # callback.register_handler('Push user L2L3 config', push_sflow_config_handle)
        # ansible_common.run_tasks(user, pw, tasks, host_map.keys(), callback)
        # inven_db.add_switch_log(info['sn'], 'changed VPN IP and change sflow config '+info['ip'], 'warn')
    elif switches.status == constants.SwitchStatus.IMPORTED:
        inven_db.update_model(inventory.Switch, {'sn': [info['sn']]}, {'mgt_ip': info['ip']})
    else:
        LOG.info("Switch %s try to update VPN IP, but it is in deploying", info['sn'])
        monitor_db.add_event(info['sn'], 'warn',
                             'Unknown switch %s try to update VPN IP, but it is in deploying' % info['sn'])
    return jsonify('update_vpn_ip')


@dashboard_mold.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == "GET":
        return render_template('login.html')
    else:
        form = request.form
        username = form.get('username', None)
        pwd = form.get('password', None)
        remember = form.get('remember', None)
        remember = True if remember == 'on' else False
        if username and pwd:
            tac_status = utils.tacacs_auth(username, pwd)
            if tac_status[0]:
                if tac_status[1][0]:
                    # authentication success
                    monitor_db.add_operation_log(username, '/login', 'login', 'success', 'username: {0} password:XXXXX'.format(username),
                        'User "{0}" success to login'.format(username))
                    auth_user = User()
                    auth_user.id = username
                    auth_user.role = 'tacacs'
                    auth_user.type = tac_status[1][1]
                    login_user(auth_user, remember=remember)
                    return redirect('/index')
                else:
                    monitor_db.add_operation_log(username, '/login', 'login', 'error', 'username: {0} password:XXXXX'.format(username),
                        'User "{0}" failed to login'.format(username))
                    msg = {'msg': 'Username or password is incorrect for TACACS+ authentication'}
                    return render_template('login.html', msg=msg)
            user = user_db.query_user(user=username)
            if user and user.passwd == pwd:
                monitor_db.add_operation_log(username, '/login', 'login', 'success', 'username: {0} password:XXXXX'.format(username),
                    'User "{0}" success to login'.format(username))
                auth_user = User()
                auth_user.id = username
                auth_user.role = 'local'
                auth_user.type = user.type
                login_user(auth_user, remember=remember)
                # session['user'] = username
                return redirect('/index')
            monitor_db.add_operation_log(username, '/login', 'login', 'error', 'username: {0} password:XXXXX'.format(username),
                'User "{0}" failed to login'.format(username))
            msg = {'msg': 'Username or Password is incorrect'}
            return render_template('login.html', msg=msg)
        else:
            monitor_db.add_operation_log(username, '/login', 'login', 'error', 'username: {0} password:XXXXX'.format(username),
                'User "{0}" failed to login'.format(username))
            msg = {'msg': 'Username or Password is empty'}
            return render_template('login.html', msg=msg)


@dashboard_mold.route('/login_out', methods=['POST', 'GET'])
def login_out():
    if request.method == "GET":
        # session.clear()
        logout_user()
        return render_template('login.html')


@dashboard_mold.route('/', methods=['POST', 'GET'])
@dashboard_mold.route('/index', methods=['POST', 'GET'])
def dashboard():
    db_session = inven_db.get_session()
    system_info = {}
    lifecycle_tasks_list = []
    #lifecycle_tasks = db_session.query(inventory.TaskStatus).filter(inventory.TaskStatus.status == 'running')
    lifecycle_tasks = db_session.query(inventory.TaskStatus)
    if lifecycle_tasks:
        for ins in lifecycle_tasks:
            lifecycle_tasks_list.append([ins.name, 'lifecycle', ins.start_date, ins.status])
    count_task = 0
    deploy_tasks = forking_manage.active_task_name or []
    deploy_tasks_list = []
    for task in deploy_tasks:
        if 'vtep' not in task and 'ssh' not in task and 'mac' not in task:
            deploy_tasks_list.append(task)
    system_info.update({"deployment": deploy_tasks_list})
    system_info.update({"lifecycle": lifecycle_tasks_list})
    #now, merge them together
    task_list = []
    for task in deploy_tasks_list:
        task_list.append([task, 'deployment', 'N/A', 'running'])
    for task in lifecycle_tasks_list:
        task_list.append(task)
    system_info.update({"task": task_list})
    system_info.update({"sdn_access": db_session.query(SdnAccessSwitch).count()})
    system_info.update({"vtep_management": db_session.query(VtepControlSwitch).count()})
    system_info.update({"global_file": db_session.query(inventory.SwitchAutoConfig).filter(inventory.SwitchAutoConfig.type == 'global').count()})
    system_info.update({"site_file": db_session.query(inventory.SwitchAutoConfig).filter(inventory.SwitchAutoConfig.type == 'site').count()})
    system_info.update({"retrieved_config": db_session.query(inventory.SwitchConfigBackup).count()})
    system_info.update({"configured_hardware": db_session.query(inventory.SwitchSystemInfo).filter(inventory.SwitchSystemInfo.up_to_date_onie_path != '').count()})
    system_info.update({"template_file": db_session.query(general.GeneralTemplate).count()})
    system_info.update({"general_config": db_session.query(general.GeneralConfig).filter(general.GeneralConfig.content != '').count()})

    if request.method == 'GET':
        # db_session = inven_db.get_session()
        # switch_message = db_session.query(Switch).filter(Switch.status.in_(['Provisioning Failed',
        #                                                                     'Registered', 'Staged',
        #                                                                     'Configured'])).order_by(
        #     Switch.modified_time.desc()).limit(5).all()
        # switch_tables = db_session.query(Switch).all()
        active = ('index', 'index')
        # return render_template("index.html", switch_message=switch_message, active=active, )
        system_config = inven_db.get_mgt_system_config()
        portal_url = system_config.license_portal_url if system_config else ''
        return render_template("index.html", active=active, license_portal_url=portal_url, system_info=system_info)

    else:
        info = request.form.to_dict()
        if info:
            session_q = inven_db.get_session()
            input = info['inputSN']
            select = info['select1']
            if select == 'SN':
                cf_content = session_q.query(inventory.Switch).filter(
                    inventory.Switch.sn.like('{}%'.format(input))).all()
            elif select == 'Address':
                cf_content = session_q.query(inventory.Switch).filter(
                    inventory.Switch.address.like('{}%'.format(input))).all()
            else:
                cf_content = session_q.query(inventory.Switch).filter(inventory.Switch.group_id == input).all()
            session_q.close()
            system_config = inven_db.get_mgt_system_config()
            portal_url = system_config.license_portal_url if system_config else ''
            return render_template("index.html",
                                   switch_list=cf_content, license_portal_url=portal_url, system_info=system_info)


@dashboard_mold.route('/index_data', methods=['POST', 'GET'])
def dashboard_data():
    if request.method == 'GET':
        db_session = inven_db.get_session()
        cpu = utils.get_CPU_state()['cpu_percent']
        mem = utils.get_memory_state()['sum_mem']
        disk = utils.get_disk_satate()['sum_disk']
        # licenses = db_session.query(monitor.LicenseCount).first()
        # licenses_status = [licenses.total, licenses.remain] if licenses else [0, 0]
        replication = get_db_sync_status(db_session=db_session)
        res_dict = {'cpu': cpu, 'mem': mem, 'disk': disk,
                    'replication': replication}
        return json.dumps(res_dict, default=str)


@dashboard_mold.route('/index_data_echar', methods=['POST', 'GET'])
def dashboard_data_echar():
    db_session = inven_db.get_session()
    echar_res = db_session.query(inventory.Switch.status, func.count(inventory.Switch.status)).group_by(
        inventory.Switch.status).all()
    echar_res = dict(echar_res)
    parking_count = db_session.query(inventory.SwitchParking).count()
    echar_res['parking'] = parking_count
    res_dict = {'echar_res': echar_res}
    echar_model = db_session.query(inventory.Switch.platform_model, func.count(inventory.Switch.platform_model)).group_by(
        inventory.Switch.platform_model).all()
    echar_res['models'] = echar_model
    echar_reachable = db_session.query(inventory.Switch.reachable_status, func.count(inventory.Switch.reachable_status)).group_by(
        inventory.Switch.reachable_status).all()
    echar_res['reachable'] = echar_reachable
    return json.dumps(res_dict, default=str)


@dashboard_mold.route('/license/portal/status')
def license_portal_status():
    db_session = inven_db.get_session()
    total_remain = 0
    total = 0
    if cfg.CONF.use_pool_license:
        license_statistic = db_session.query(monitor.LicenseStatisttic).first()
        if license_statistic:
            total_remain = license_statistic.remain
            total = license_statistic.total
        return jsonify({'total': total, 'remain': total_remain})
    else:
        licenses = db_session.query(monitor.LicenseCount).all()
        for license in licenses:
            total_remain += license.remain
            total += license.total
        return jsonify({'total': total, 'remain': total_remain})

    


@dashboard_mold.route('/switch/license/expiring')
def license_expiring():
    now_month = datetime.date.today()
    end_month = pure_utils.date_offset_by_month(now_month, 6)
    reses = inven_db.get_last_license_expired(now_month, end_month)
    db_month_c = dict(reses)
    show_months = [pure_utils.date_offset_by_month(now_month, i) for i in range(6)]
    keys = []
    values = []
    for show_month in show_months:
        m_str = show_month.strftime('%Y-%m')
        keys.append(m_str)
        values.append(db_month_c.get(m_str, 0))
    return jsonify({'keys': keys, 'values': values})


@dashboard_mold.route('/host/access/vlan/statics')
def host_access_statics():
    statics = sdn_access_db.get_vlan_statics()
    json_data = []
    for static in statics:
        json_data.append({'name': 'vlan_' + str(static.assigned_vlan_id), 'value': static.count})
    return jsonify(json_data)


@dashboard_mold.route('/virtual/statics')
def virtual_statics():
    statics = vtep_db.get_vxlan_statics()
    json_data = []
    for static in statics:
        json_data.append({'name': 'vxlan_' + static.vni, 'value': static.count})
    return jsonify(json_data)


@dashboard_mold.route('/index_data_lastactivity', methods=['POST', 'GET'])
def dashboard_data_lastactivity():
    db_session = inven_db.get_session()
    switch_message = db_session.query(inventory.Switch).filter(inventory.Switch.status.in_(['Provisioning Failed',
                                                                        'Registered', 'Staged',
                                                                        'Configured'])).order_by(
        inventory.Switch.modified_time.desc()).limit(5).all()
    # switch_tables = db_session.query(Switch).all()
    switch_list = [switch.make_dict() for switch in switch_message]
    res_dict = {'switch_message': switch_list}
    return json.dumps(res_dict, default=str)


@dashboard_mold.route('/switch_table/data')
def switch_table():
    rule = None
    status_filter = None
    host_name = request.args.get('columns[0][search][value]', '')
    # address = request.args.get('columns[2][search][value]', '')
    platform_ = request.args.get('columns[2][search][value]', '')
    version = request.args.get('columns[3][search][value]', '')
    status = request.args.get('columns[4][search][value]', '')
    ip = request.args.get('columns[5][search][value]', '')
    group_name = request.args.get('columns[6][search][value]', '')

    session = inven_db.get_session()
    filter_rules = []
    if host_name != '':
        filter_rules.append(Switch.host_name.like('%' + host_name + '%'))
    # if address != '':
    #     filter_rules.append(Switch.address.like('%' + address + '%'))
    if ip != '':
        filter_rules.append(Switch.mgt_ip.like('%' + ip + '%'))
    if platform_ != '' and platform_ != 'All':
        filter_rules.append(Switch.platform_model == platform_)
    if version != '' and version != 'All':
        filter_rules.append(Switch.version == version)
    if status != '' and status != 'All':
        filter_rules.append(Switch.status == status)
    if group_name != '' and group_name != 'All':
        subquery = session.query(AssociationGroup.switch_sn).filter(
            AssociationGroup.group_name == group_name).subquery()
        filter_rules.append(Switch.sn.in_(subquery))

    if filter_rules:
        rule = and_(*filter_rules)

    return utils.page_helper(request.args, inventory.Switch, rule=rule, extra_filter=status_filter)


@dashboard_mold.route('/switch_table/picos_v')
def switch_table_picos_v():
    filter_rules = [Switch.sn.like('PICOS_V')]
    rule = and_(*filter_rules)
    session = inven_db.get_session()
    results = session.query(inventory.Switch).filter(rule).all()
    return json.dumps({'data': [result.make_dict() for result in results]}, default=str)


@dashboard_mold.route('/picos_v_support_model_list')
def picos_v_support_model_list():
    return json.dumps({'data': get_picos_v_support_model_list()}, default=str)


@dashboard_mold.route('/modify_picos_v_model', methods=['POST'])
def modify_picos_v_model():
    model = request.get_json().get('model')
    if not model in get_picos_v_support_model_list():
        json.dumps({'data': 'model parameter error'}, default=str)
    result = switch_picos_v_model(model)
    if result == 'OK':
        modify_picos_v_switch_list(model)
    return json.dumps({'data': result}, default=str)


@dashboard_mold.route('/all_switch_table/data')
def all_switch_table():
    rule = None
    status_filter = None
    search_value = request.args.get('search[value]', '')
    status_value = request.args.get('columns[4][search][value]', '')

    if status_value and status_value != '':
        status_filter = inventory.Switch.status.in_([status_value])

    if search_value and search_value != '':
        search_value = '%' + search_value + '%'
        rule = or_(*[inventory.Switch.sn.like(search_value),
                     ])

    return utils.page_helper(request.args, inventory.Switch, rule=rule, extra_filter=status_filter)


@dashboard_mold.route('/index/<string:sn>')
def dashboard_sn(sn):
    # q1 = session.query(PicModel).filter(PicModel.name == picname).first()
    res = inven_db.get_switch_info_by_sn_match(sn)
    return render_template("index.html", switch_list=res)


@dashboard_mold.route('/switch/<string:sn>/agent_conf')
def display_agent_conf(sn):
    conf_str = inven_db.get_switch_agent_conf(sn)
    return conf_str if conf_str else 'no agent conf'


@dashboard_mold.route('/display_conf/<string:sn>')
def display_conf(sn):
    try:
        db_session = inven_db.get_session()
        if sn.endswith('.rma'):
            sn = sn.replace('.rma', '')
            config = inven_db.get_switch_back_sn(sn, session=db_session)
            return config or 'No RMA config'

        else:
            switch = db_session.query(inventory.Switch).filter(inventory.Switch.sn == sn).first()
            if switch.configs or switch.general_configs:
                global_config = regional_config = site_config = switch_config = ''
                for switch_config in switch.configs:
                    if switch_config.type == 'global':
                        global_config = switch_config.config
                    # elif switch_config.type == 'regional':
                    #     regional_config = switch_config.config
                    elif switch_config.type == 'site':
                        site_config = switch_config.config
                    # else:
                    #     switch_config = switch_config.config
                config = global_config + '\n' + site_config
                for general_config in switch.general_configs:
                    config += general_config.content
                config = key_reg.sub('key ***', config)
                config = password_reg.sub('password ***', config)
                return config
            else:
                config = '%s No Switch Config' % sn
                return config
    except Exception as e:
        config = '%s No Switch Config' % sn
        return config


@dashboard_mold.route('/display_log/<string:sn>')
def display_log(sn):
    switch_logs = inven_db.get_switch_logs(sn)
    switch_log = ''
    if switch_logs:
        for switch in switch_logs:
            switch_log += str(switch.create_time) + ': ' + switch.content + '\n'
    switch_log = str_helper.mask_key_configuration(switch_log)
    return switch_log


@dashboard_mold.route('/report/<string:sn>')
def report(sn):
    db_session = inven_db.get_session()
    switch_logs = db_session.query(
        inventory.SwitchLog).filter(inventory.SwitchLog.switch_id == sn, inventory.SwitchLog.level == 'info').order_by(
        'create_time').all()
    # success_num = db_session.query(SwitchLog).filter(SwitchLog.switch_id == sn, SwitchLog.level == 'info').filter(
    #     SwitchLog.switch_id == sn, SwitchLog.content.like('%uccess%')).count()
    # failed_num = db_session.query(SwitchLog).filter(SwitchLog.switch_id == sn, SwitchLog.level == 'info').filter(
    #     SwitchLog.switch_id == sn, SwitchLog.content.like('%ailed%')).count()

    for i, switch_log in enumerate(reversed(switch_logs)):
        if ':::::Register Start::::::register the switch begin' in switch_log.content:
            j = -(i + 1)
            switch_logs = switch_logs[j:]

    switch_log = ''
    if switch_logs:
        for switch in switch_logs:
            switch_log += str(switch.create_time) + ': ' + switch.content + '\n'

    # switch_log += '\n' + '----------------------Summary-----------------------' + '\n'
    # switch_log += 'Success Task: ' + str(success_num) + '\n'
    # switch_log += 'Failed Task: ' + str(failed_num) + '\n'
    return switch_log


@dashboard_mold.route('/del_switch', methods=['POST'])
@utils.operation_log(method='delete_deploying_switch', contents='delete deploying switch {sn}')
def del_switch():
    req_json = request.get_json()
    sn = req_json.get('sn')
    try:
        db_session = inven_db.get_session()
        db_session.begin()
        switch = db_session.query(inventory.Switch).filter(inventory.Switch.sn == sn).first()

        if switch:
            allow_config_list = ['global', 'regional']
            for config in switch.configs:
                if config.type not in allow_config_list:
                    db_session.delete(config)

            if forking_manage.is_task_run(sn):
                forking_manage.kill_process(sn)
            db_session.delete(switch)
            db_session.commit()
            # msg = 'The %s switch del success' % sn
            # flash(msg, category='success')
            msg = {'status': '200', 'info': 'The %s switch is removed success!' % sn}

            db_session.query(inventory.SwitchConfigBackup).filter(inventory.SwitchConfigBackup.sn == sn).delete()
            db_session.query(inventory.DeployedSecuritySwitch).filter(inventory.DeployedSecuritySwitch.sn == sn).delete()
        else:
            msg = {'status': '400', 'info': 'The %s switch is not exit' % sn}
    except Exception as e:
        LOG.exception(e)
        msg = {'status': '500', 'info': 'The %s switch del error' % sn}
    finally:
        return jsonify(msg)


def get_db_sync_status(db_session=None):
    result_proxy = None
    try:
        db_session = db_session or inven_db.get_session()
        result_proxy = db_session.execute('show slave status')
        replication_status = result_proxy.first()

        if not replication_status:
            return {'error': 'no sync'}

        if replication_status['Slave_IO_Running'] == 'Yes' and replication_status['Slave_SQL_Running'] == 'Yes':
            if 'Seconds_Behind_Master' in replication_status:
                return {'status': 'running', 'delay': replication_status['Seconds_Behind_Master']}
            if 'SQL_Delay' in replication_status:
                return {'status': 'running', 'delay': replication_status['SQL_Delay']}
        else:
            error_result = {'status': 'stopped by error'}
            if replication_status['Slave_IO_Running'] != 'Yes':
                error_result['io_error'] = replication_status['Last_IO_Error']
            if replication_status['Slave_SQL_Running'] != 'Yes':
                error_result['sql_error'] = replication_status['Last_SQL_Error']
            return error_result
    except Exception as e:
        return {'error': e.message}
    finally:
        if result_proxy:
            result_proxy.close()


@dashboard_mold.route('/enable_switch', methods=['POST'])
@utils.operation_log(method='enable_switch', contents='staged deploying switch {sn}')
def enable_switch():
    try:
        res = request.get_json()
        sn = res.get('sn')
        db_switch = inven_db.get_model(inventory.Switch, filters={'sn': [sn]})
        if db_switch:
            db_switch.enable = True
            db_switch.status = 'Staged'
            inven_db.merge(db_switch)
            msg = {'status': '200', 'info': 'The %s staged' % sn}
            from server.vpn.vpn_utils import create_vpn_client
            create_vpn_client(sn)
        else:
            msg = {'status': '500', 'info': 'The %s switch not exist' % sn}
    except Exception as e:
        LOG.exception(e)
        msg = {'status': '500', 'info': 'The %s staged error' % sn}
    finally:
        return jsonify(msg)


@dashboard_mold.route('/switch/<string:sn>/unstage', methods=['GET'])
@utils.operation_log(method='unstage_switch', contents='unstaged deploying switch {sn}')
def unstage_switch(sn):
    msg, flag = inven_db.unstage_switch(sn)
    if flag:
        return msg

    return Response(msg, status=500)


@dashboard_mold.route('/favicon.ico')
def get_fav():
    return current_app.send_static_file('img/favicon.ico')


@dashboard_mold.route('/switch_message')
def switch_message():
    active = ('index', 'index')
    return render_template('display_switch_message.html', active=active)


@dashboard_mold.route('/file/transfer', methods=['POST'])
def file_transfer():
    try:
        params = request.form
        files = request.files
        import flask_login
        print flask_login.current_user.id
        for value in files.values():
            path = params.get(value.filename)
            if not os.path.exists(os.path.dirname(path)):
                os.makedirs(os.path.dirname(path))
            value.save(path)
    except Exception as e:
        LOG.exception('error in transfer file %s', e)
        return Response(status=500, response='error in transfer file %s' % e.message)

    return 'ok'


@dashboard_mold.route('/switch_status/<string:sn>')
def switch_status(sn):
    db_switch = inven_db.get_model(inventory.Switch, filters={'sn': [sn]})
    return db_switch.make_dict()


@dashboard_mold.route('/system_cli/<string:cmd>')
def system_cli(cmd):
    import commands
    try:
        c = commands.getoutput(cmd)
    except Exception as e:
        print e
        c = 'Command execution failed'
    finally:
        return c


@dashboard_mold.route('/debug/<int:flag>')
def enable_or_disable_debug(flag):
    if flag == 0:
        server_log.enable_debug()
        LOG.debug('enable debug')
    else:
        server_log.init_log_level()
        LOG.debug('disable debug')
    return 'ok'


@dashboard_mold.route('/debug/enable')
def is_enable_debug():
    return str(server_log.is_enable_debug())


@dashboard_mold.route('/system/backup', methods=['POST'])
def system_backup():
    base_dir = os.path.abspath(constants.SYSTEM_BACKUP_DIR)
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)

    license_path = os.path.abspath('license')
    os.system('cp -rf %s %s' % (license_path, base_dir))
    img_path = os.path.abspath('img')
    os.system('cp -rf %s %s' % (img_path, base_dir))
    config_gen_path = os.path.abspath('config_gen')
    os.system('cp -rf %s %s' % (config_gen_path, base_dir))
    backup_database_path = '%s/automation.sql' % base_dir
    status = os.system('mysqldump -uroot -proot --databases automation '
                       '> %s' % backup_database_path)
    if status != 0:
        return Response('backup database failed', status=500)

    # date = datetime.datetime.now().strftime('%Y-%m-%d')
    # tar_filename = 'automation_%s_backup' % date
    # tar = tarfile.open(tar_filename, 'w|gz')
    # try:
    #     tar.add(base_dir)
    # finally:
    #     tar.close()
    # return send_from_directory(current_app.root_path, tar_filename, as_attachment=True)
    return 'ok'


@dashboard_mold.route('/system/recover', methods=['POST'])
def system_recover():
    # back_file = request.files.get('backup_file', None)
    # if not back_file:
    #     return Response('No Backup File', status=400)

    base_dir = os.path.abspath(constants.SYSTEM_BACKUP_DIR)
    if not os.path.exists(base_dir):
        return Response('no backup file found, please backup first', status=400)

    license_path = base_dir + '/license'
    os.system('cp -rf %s %s' % (license_path, 'license'))
    img_path = base_dir + '/img'
    os.system('cp -rf %s %s' % (img_path, 'img'))
    config_gen_path = base_dir + '/config_gen'
    os.system('cp -rf %s %s' % (config_gen_path, 'config_gen'))
    # recover database
    status = os.system('mysql -uroot -proot -e "set  @@global.foreign_key_checks = 0;"')
    if status != 0:
        return Response('recover database failed', status=500)

    backup_database_path = '%s/automation.sql' % base_dir
    status = os.system('mysql -uroot -proot < %s' % backup_database_path)
    if status != 0:
        return Response('recover database failed', status=500)

    status = os.system('mysql -uroot -proot -e "set  @@global.foreign_key_checks = 1;"')
    if status != 0:
        return Response('recover database failed', status=500)

    logout_user()
    return 'ok'

@dashboard_mold.route('/token', methods=['POST'])
def generate_token():
    params = request.get_json()
    username = params.get('username', '')
    password = params.get('password', '')

    status, msg, role = web_auth(username, password)
    if status:
        if role == 'superuser':
            j_encoded, res_msg = auth_handles.get_jwt_token(username, password)
            return j_encoded
        else:
            return jsonify({'msg': 'Permission denied, you should use "superadmin" user'})
    else:
        return jsonify(msg)
