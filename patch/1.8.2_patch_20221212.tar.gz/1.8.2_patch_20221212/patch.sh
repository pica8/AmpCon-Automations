#!/bin/sh
cp /usr/share/automation/server/ansible_deploy_switch.py /usr/share/automation/server/ansible_deploy_switch.py_bak
cp /usr/share/automation/server/api/dashboard_api.py /usr/share/automation/server/api/dashboard_api.py_bak
cp /usr/share/automation/server/api/management_api.py /usr/share/automation/server/api/management_api.py_bak
cp /usr/share/automation/server/util/utils.py /usr/share/automation/server/util/utils.py_bak

cp ansible_deploy_switch.py /usr/share/automation/server/
cp dashboard_api.py /usr/share/automation/server/api/
cp management_api.py /usr/share/automation/server/api/
cp utils.py /usr/share/automation/server/util/

echo 'Restart Automation Service ...'
systemctl restart automation
echo 'Restart Automation Service [Success]'
