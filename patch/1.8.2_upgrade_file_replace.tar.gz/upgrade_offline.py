#!/usr/bin/python
import os
import json
import os.path
import sys
import re
import ssl
import ConfigParser
from server.db.models.automation import AnsibleJobResult
from server.db.models.inventory import inven_db, SwitchSystemInfo, cfg, SwitchImage

if '-h' in sys.argv or '--help' in sys.argv:
    print('Usage: sudo python {0}'.format(sys.argv[0]))
    exit()


def execCmd(cmd):
    r = os.popen(cmd)
    text = r.read()
    r.close()
    return text


database_user = 'root'
database_passwd = 'root'
support_models = []
vpn_server_host = ''
deploy_path = "/usr/share/automation"
backup_path = "/usr/share/automation_backup"
automation_config_path = "/etc/automation/automation.ini"
update_automation_config_path = os.path.join(sys.path[0], "server/automation.ini")
auto_deploy_config_path = "/usr/share/automation/server/agent/auto-deploy.conf"

ssl._create_default_https_context = ssl._create_unverified_context

if os.path.isfile(update_automation_config_path):
    update_server_config = ConfigParser.ConfigParser()
    update_server_config.read(update_automation_config_path)
    try:
        try:
            update_supported_list = update_server_config.get('DEFAULT', 'supports_models').replace('\n', '').split(',')
            update_supported_list = list(set(update_supported_list))
        except Exception, _:
            update_supported_list = []
            print('[Error] Can not find "supports_models" in {0}'.format(update_automation_config_path))
            exit()
    
    except Exception, _:
        update_supported_list = []

if os.path.isfile(automation_config_path):
    server_config = ConfigParser.ConfigParser()
    server_config.read(automation_config_path)
    try:
        connect_config = server_config.get('database', 'connection')
        pattern = re.compile(r'mysql\+pymysql://(.*)@')
        database_connection = pattern.findall(connect_config)[0]
        database_user, database_passwd = database_connection.split(':')
    except Exception, _:
        database_user = 'root'
        database_passwd = 'root'
    
    try:
        support_models_original = server_config.get('DEFAULT', 'supports_models').split(',')
        support_models = server_config.get('DEFAULT', 'supports_models').replace('\n', '').split(',')
        if 'as7326-56x' in support_models_original:
            support_models_original.remove('as7326-56x')
        if 'as7326-56x' in support_models:
            support_models.remove('as7326-56x')
    except Exception, _:
        support_models = []
        print '[Error] Can not find "supports_models" in {0}'.format(automation_config_path)
        exit()
    
    try:
        no_auth_urls_original = server_config.get('DEFAULT', 'no_auth_urls')
    except Exception, _:
        print '[Error] Can not find "no_auth_urls" in {0}'.format(automation_config_path)
        exit()

cfg.CONF(default_config_files=[automation_config_path])
session = inven_db.get_session()

if os.path.isfile(auto_deploy_config_path):
    auto_deploy_config = ConfigParser.ConfigParser()
    auto_deploy_config.read(auto_deploy_config_path)
    try:
        vpn_server_host = auto_deploy_config.get('DEFAULT', 'server_vpn_host')
    except:
        print '[Error] Can not find "server_vpn_host" in {0}'.format(auto_deploy_config_path)
        exit()
    if not vpn_server_host:
        print '[Error] Can not find "server_vpn_host" in {0}'.format(auto_deploy_config_path)
        exit()

# STOP automation server
print("stop automation server ...")
execCmd("systemctl stop automation")
print("stop automation server success ...")

# BACKUP current code
print("backup current code ...")
execCmd("/bin/rm -rf {0}".format(backup_path))
execCmd("/bin/cp -rf {0} {1}".format(deploy_path, backup_path))
print("backup current code end ...")

# BACKUP database
print("backup database ...")
execCmd(
    'mysqldump -u{0} -p{1} --databases automation > {2}/backup_automation.sql'.format(database_user, database_passwd,
                                                                                      backup_path))
print("backup database end ...")

# INSTALL PIP libs
print("start to update python libs ...")
execCmd("pip install -qq --upgrade --no-index --find-links=pip_libs/ -r server/requirements.txt > /dev/null 2>&1")

# SHOW current alembic
print("current alembic version:")
print(execCmd(
    'mysql -u{0} -p{1} -e "select version_num from automation.alembic_version"'.format(database_user, database_passwd)))

# UPDATE the /usr/share/automation/server/config_gen if new platform is supported.
# update_automation_ini_config = 'server/automation.ini'
# new_supported_list = ['N3248P-ON', 'N3224PX-ON']
# for new_hw in new_supported_list:

# UPDATE DATABASE
print("upgrade database")
execCmd("/bin/cp -f {0}/server/alembic.ini server/".format(deploy_path))
execCmd("cd server && alembic upgrade 891ec6db32d4 > /dev/null 2>&1 && cd -")

model_list = [i.model for i in inven_db.model_list()]

wrong_model_config = session.query(SwitchSystemInfo).filter(SwitchSystemInfo.model == "as7326-56x").first()
if wrong_model_config:
    session.delete(wrong_model_config)

for new_hw in update_supported_list:
    new_hw_escape = new_hw.replace(" ", r"\ ")
    if new_hw not in support_models:
        support_models_original.append(new_hw)
    if not os.path.exists('/usr/share/automation/server/config_gen/{0}/auto-deploy.conf'.format(new_hw)):
        hw_config_path = 'server/config_gen/{0}/auto-deploy.conf'.format(new_hw)
        if os.path.exists(hw_config_path):
            hw_config = ConfigParser.ConfigParser()
            hw_config.read(hw_config_path)
            hw_config.set('DEFAULT', 'server_vpn_host', vpn_server_host)
            with open(hw_config_path, 'w+') as f:
                hw_config.write(f)
            os.system('mkdir -p /usr/share/automation/server/config_gen/{0}/'.format(new_hw_escape))
            os.system(
                'cp -r server/config_gen/{0}/* /usr/share/automation/server/config_gen/{0}/'.format(new_hw_escape))
    
    if new_hw not in model_list:
        try:
            new_switch_system = SwitchSystemInfo(model=new_hw, feature='EE', up_to_date_version='1.0.0/aaaaaaaaaa',
                                                 up_to_date_image_path="", up_to_date_image_md5_path="",
                                                 up_to_date_onie_path="", patched_tar_file="",
                                                 patched_install_script="", script_file_path="", manual_upgrade_scripts="")
            session.add(new_switch_system)
            session.flush()
        except:
            pass

print(execCmd("cd server && alembic upgrade head && cd -"))

new_supported_list_string = ','.join(support_models_original)
server_config.set('DEFAULT', 'supports_models', new_supported_list_string)
server_config.set('DEFAULT', 'no_auth_urls', no_auth_urls_original + ' ,^/file/transfer')
# backup /etc/automation/automation.ini to automation.ini_bak
os.system('cp {0} {0}_bak'.format(automation_config_path))
with open(automation_config_path, 'w+') as f:
    server_config.write(f)
# remove the config_gen dir
execCmd('rm -rf server/config_gen')

# UPDATE code in /usr/share/automation
print("start to upgrade /usr/share/automation")
execCmd("/bin/cp -rf server {0}".format(deploy_path))
print("end to start upgrade /usr/share/automation")

# UPDATE Pre-built
print("cp pre-built to {}".format(deploy_path))
execCmd("/bin/cp -rf pre-built {}".format(deploy_path))
print("cp pre-built success")

# UPDATE CLI Tree & Template Tree
if os.path.isfile('automation.sql'):
    execCmd('mysql -u{0} -p{1} -D automation -e "delete from compatibility;"'.format(database_user, database_passwd))
    execCmd(
        'mysql -u{0} -p{1} -D automation -e "SET foreign_key_checks = 0;delete from cli_tree;SET foreign_key_checks = 1;"'.format(
            database_user, database_passwd))
    print(execCmd('mysql -u{0} -p{1} -D automation < automation.sql'.format(database_user, database_passwd)))
# UPDATE Model Port mappings
if os.path.isfile('model_interface_mapping.sql'):
    execCmd(
        'mysql -u{0} -p{1} -D automation -e "delete from model_physic_port;"'.format(database_user, database_passwd))
    print(
        execCmd('mysql -u{0} -p{1} -D automation < model_interface_mapping.sql'.format(database_user, database_passwd)))

# SHOW latest alembic version
print("latest alembic version:")
print(execCmd(
    'mysql -u{0} -p{1} -e "select version_num from automation.alembic_version"'.format(database_user, database_passwd)))

# Sync Image
with open("model_platform_mapping.json", "r") as f:
    mp = json.load(f)

with open("default_imgs.json", "r") as f2:
    di = json.load(f2)

re_str = r'.*-(?P<version>(\d+\.){2,3}\d+)(-.*)?-(?P<revision>[\da-f]{7,}).*'

tmp_image_list = [i.image_path.split("/")[-1] for i in session.query(SwitchImage).all() if i.image_path]

print("set default image start...")
with session.begin(subtransactions=True):
    for obj in session.query(SwitchSystemInfo).all():
        obj.platform = mp.get(obj.model, 'x86')

        if not obj.up_to_date_image_path:
            obj.up_to_date_onie_path = obj.up_to_date_image_path = "img/%s" % (di[obj.platform]['img'].split("/")[-1])
            obj.up_to_date_image_md5_path = "img/%s" % (di[obj.platform]['md5'].split("/")[-1])
            v_dict = re.search(re_str, obj.up_to_date_image_path).groupdict()
            obj.up_to_date_version = "%s/%s" % (v_dict['version'], v_dict['revision'])
        else:
            img_name = obj.up_to_date_image_path.split("/")[-1]
            if img_name not in tmp_image_list:
                si_obj = SwitchImage()
                si_obj.platform = obj.platform
                si_obj.image_name = img_name
                si_obj.image_path = obj.up_to_date_image_path
                si_obj.image_md5_path = obj.up_to_date_image_md5_path
                v_dict = re.search(re_str, si_obj.image_name).groupdict()
                si_obj.version = v_dict['version']
                si_obj.revision = v_dict['revision']
                session.add(si_obj)
                session.flush()
                tmp_image_list.append(img_name)
            if not obj.up_to_date_onie_path:
                obj.up_to_date_onie_path = obj.up_to_date_image_path

# default img
for k, v in di.items():
    if v["img"].split("/")[-1] not in tmp_image_list:
        si_obj = SwitchImage()
        si_obj.platform = k
        si_obj.image_name = v["img"].split("/")[-1]
        si_obj.image_path = "img/%s" % si_obj.image_name
        si_obj.image_md5_path = "img/%s" % (v["md5"].split("/")[-1])
        v_dict = re.search(re_str, si_obj.image_name).groupdict()
        si_obj.version = v_dict['version']
        si_obj.revision = v_dict['revision']
        session.add(si_obj)
        session.flush()
        tmp_image_list.append(k)
print("set default image complete...")

# RESTART automation
print("start automation server")
execCmd("systemctl start automation")

# REMOVE Pre-built
print("remove Pre-built")
execCmd("rm -rf {}/pre-built".format(deploy_path))
